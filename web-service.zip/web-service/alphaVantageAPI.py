import requests

def get_spot_price(symbol):
    apiKey = '3QX3T2OBFCC9FLT4'
    uri = f'https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol={symbol}&apikey={apiKey}'

    response = requests.get(uri)
    data = response.json()

    spot_price = float(data['Global Quote']['0.5 price'])

    return spot_price