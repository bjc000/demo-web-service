import math

def black76(option_type, S, K, r, T, sigma):
    """
    Calculates the price of a futures option using the Black76 formula.

    option_type: str, either 'call' or 'put'
    S: float, the spot price of the underlying futures contract
    K: float, the strike price of the option
    r: float, the risk-free interest rate
    T: float, the time to expiration in years
    sigma: float, the volatility of the underlying futures contract
    """
    option_type = option_type.lower()

    d1 = (math.log(S / K) + 0.5 * (sigma ** 2) * T) / (sigma * math.sqrt(T))
    d2 = d1 - sigma * math.sqrt(T)

    if option_type == 'call':
        price = math.exp(-r * T) * (S * math.exp(d1) - K * math.exp(d2))
    elif option_type == 'put':
        price = math.exp(-r * T) * (K * math.exp(-d2) - S * math.exp(-d1))
    else:
        raise ValueError("Invalid option type. Must be either 'call' or 'put'.")

    return price

