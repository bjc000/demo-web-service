from flask import Flask, request, jsonify 
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from black_scholes import *
from black_scholes import black76

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///market_data.db'
db = SQLAlchemy(app)

class MarketData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    option_type = db.Column(db.String(50))
    underlying_symbol = db.Column(db.String(5))
    underlying = db.Column(db.String(50))
    spot_price = db.Column(db.Float)
    expiry_date = db.Column(db.DateTime(10))
    strike_price = db.Column(db.Float)
    risk_free_rate = db.Column(db.Float)
    sigma = db.Column(db.Float) 
    currency = db.Column(db.String(10))
    price = db.Column(db.Float)
    input_time = db.Column(db.DateTime(10))

    def to_dict(self):
        return {
            'id': self.id,
            'option_type': self.option_type,
            'underlying_symbol': self.underlying_symbol,
            'underlying': self.underlying,
            'spot_price': self.spot_price,
            'expiry_date': self.expiry_date,
            'strike_price': self.strike_price,
            'risk_free_rate': self.risk_free_rate,
            'sigma': self.sigma,
            'currency': self.currency,
            'price': self.price,
            'input_time': self.input_time
        }


@app.route('/options-pricing', methods=['POST']) 
def upload_market_data():
    data = request.json

    expDate = datetime.strptime(data['expiry_date'], "%Y-%m-%d").date()
    today = (datetime.today()).date()

    expDays = expDate - today
    expYears = expDays.days / 365.25
    try:
        black76_price = black76(data['option_type'], data['spot_price'], data['strike_price'], data['risk_free_rate'], expYears, data['sigma'])
    except:
        black76_price = 0

    market_data = MarketData(
        option_type=data['option_type'],
        underlying_symbol=data['underlying_symbol'],
        underlying=data['underlying'],
        spot_price=data['spot_price'],
        expiry_date=expDate,
        strike_price=data['strike_price'],
        risk_free_rate=data['risk_free_rate'],
        sigma=data['sigma'],
        currency=data['currency'],
        price=black76_price,
        input_time=datetime.now()
    )
    db.session.add(market_data)
    db.session.commit()
    return jsonify({'message': 'Market data uploaded successfully', 'id': market_data.id }), 201


@app.route('/options-pricing/<int:market_data_id>', methods=['GET']) 
def get_market_data(market_data_id):
    market_data = MarketData.query.get(market_data_id)
    if market_data is None:
        return jsonify({'message': 'Market data not found'}), 404
    return jsonify(market_data.to_dict()), 200


@app.route('/options-pricing/all', methods=['GET']) 
def get_market_dataket_data_all():
    market_data = MarketData.query.all()
    if market_data is None:
        return jsonify({'message': 'Market data not found'}), 404
    return jsonify([data.to_dict() for data in market_data]), 200


if __name__ == '__main__':
    with app.app_context():    
        db.create_all()
        app.run()