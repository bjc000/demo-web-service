
$baseUri = 'http://127.0.0.1:5000';

$body = [ordered]@{
    option_type="call"
    underlying_symbol="BRN"
    underlying="ICE Brent Jan-24 Future"
    spot_price=2.48
    expiry_date="2023-11-30"
    strike_price=100
    risk_free_rate=0.04
    sigma=0.45
    currency="USD/BBL"
}
$json = $body | ConvertTo-Json;

$rtn = Invoke-RestMethod -Method 'Post' -Uri "$baseUri/options-pricing" -Body $json -ContentType "application/json";
Write-Host $rtn;
$id = $rtn.id;

$mktDataJson = Invoke-RestMethod -Method 'Get' -Uri "$baseUri/options-pricing/$id";
Write-Host $mktDataJson;


$body = [ordered]@{
    option_type="put"
    underlying_symbol="HH"
    underlying="Henry Hub Gas Mar-24 Future"
    spot_price=0.72
    expiry_date="2022-02-28"
    strike_price=10
    risk_free_rate=0.04
    sigma=0.45
    currency="USD/MMBTu"
}
$json = $body | ConvertTo-Json;

$rtn = Invoke-RestMethod -Method 'Post' -Uri "$baseUri/options-pricing" -Body $json -ContentType "application/json";
Write-Host $rtn;

$mktDataJson = Invoke-RestMethod -Method 'Get' -Uri "$baseUri/options-pricing/$id";
Write-Host $mktDataJson;

$mktDataJson = Invoke-RestMethod -Method 'Get' -Uri "$baseUri/options-pricing/all";
$mktDataJson | Format-Table;

<#  
BRN Jan24 Call Strike 100 USD/BBL
HH Mar24 Put Strike 10 USD/MMBTu
 
A note on the contract notation. 
A BRN Jan-24 option is a European option with underlying ICE Brent Jan-24 Future contract. 
BRN option expiry will be the last business day of the 2nd month before the delivery month. 
For example, BRN Jan-24 expiry date is 2023-11-30.

HH Mar-24 option is a European option with underlying Henry Hub Gas March 24 Future contract. 
HH option expiry is the last business day of the month before the delivery month. 
For example, HH Mar-24 expiry date is 2022-02-29.


BRN Jan24
'option_type' : Call,
'underlying'  : ICE Brent Jan-24 Future,
'expiry_date' : 2023-11-30,
'strike_price': 100,
'currency'    : USD/BBL

HH Mar24
'option_type' : Put,
'underlying'  : Henry Hub Gas Mar-24 Future,
'expiry_date' : 2022-02-29,
'strike_price': 10,
'currency'    : USD/MMBTu

#>
